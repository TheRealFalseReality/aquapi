#include "calibration_number.h"
#include "esphome/core/log.h"

namespace esphome::bl0940 {

static const char *const TAG = "bl0940.number";

void CalibrationNumber::setup() {
  float value = 0.0f;
  if (this->restore_value_) {
    this->pref_ = this->make_entity_preference<float>();
    if (!this->pref_.load(&value)) {
      value = 0.0f;
    }
  }
  this->publish_state(value);
}

void CalibrationNumber::control(float value) {
  this->publish_state(value);
  if (this->restore_value_)
    this->pref_.save(&value);
}

void CalibrationNumber::dump_config() { LOG_NUMBER("", "Calibration Number", this); }

}  // namespace esphome::bl0940
